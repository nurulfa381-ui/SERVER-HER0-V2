const missionsContainer = document.getElementById("missions");

missions.forEach((mission) => {

    const card = document.createElement("div");
    card.className = `mission ${mission.status}`;

    card.innerHTML = `
        <h2>${mission.title}</h2>
        <p>${mission.description}</p>
        <p><strong>XP:</strong> ${mission.xp}</p>
        <button ${mission.status === "locked" ? "disabled" : ""}>
            ${mission.status === "available" ? "Start Mission" : "Locked"}
        </button>
    `;

    missionsContainer.appendChild(card);

});

const missionCards = document.querySelectorAll(".mission");

const xpDisplay = document.getElementById("xp");
const progress = document.getElementById("progress");
const percentDisplay = document.getElementById("percent");

let xp = 500;
let completed = 0;

// ===== LOAD SAVE DATA =====

if(localStorage.getItem("lesson1Complete") === "true"){
    completed = 1;
    xp = 1000;
}

if(localStorage.getItem("lesson2Complete") === "true"){
    completed = 2;
    xp = 1600;
}

xpDisplay.textContent = xp;

progress.value = completed * 20;

percentDisplay.textContent = (completed * 20) + "%";

// ===========================

missionCards.forEach((mission,index)=>{

    const button = mission.querySelector("button");

    // Mission 1 Completed
    if(index===0 && localStorage.getItem("lesson1Complete") === "true"){

        mission.classList.add("completed");
        button.textContent="Completed";
        button.disabled=true;

    }

    // Unlock Mission 2
    if(index===1 && localStorage.getItem("lesson1Complete")==="true"){

        mission.classList.remove("locked");
        button.disabled=false;
        button.textContent="Start Mission";

    }

    // Mission 2 Completed
    if(index===1 && localStorage.getItem("lesson2Complete")==="true"){

        mission.classList.add("completed");
        button.textContent="Completed";
        button.disabled=true;

    }

    // Unlock Mission 3
    if(index===2 && localStorage.getItem("lesson2Complete")==="true"){

        mission.classList.remove("locked");
        button.disabled=false;
        button.textContent="Start Mission";

    }

    button.addEventListener("click",()=>{

        if(button.disabled) return;

        switch(index){

            case 0:
                window.location.href="lesson1.html";
                break;

            case 1:
                window.location.href="lesson2.html";
                break;

            case 2:
                window.location.href="lesson3.html";
                break;

            case 3:
                alert("Mission 4 Coming Soon");
                break;

            case 4:
                alert("Mission 5 Coming Soon");
                break;

            case 5:
                alert("Mission 6 Coming Soon");
                break;

            case 6:
                alert("Mission 7 Coming Soon");
                break;

            case 7:
                alert("Mission 8 Coming Soon");
                break;

        }

    });

});

// Check Lesson 3 Completion
if(localStorage.getItem("lesson3Complete")==="true"){

completed = 3;

xp = 2400;

xpDisplay.textContent = xp;

progress.value = 60;

percentDisplay.textContent = "60%";

}