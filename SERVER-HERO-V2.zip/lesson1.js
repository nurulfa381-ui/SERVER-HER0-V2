const completeBtn = document.getElementById("completeBtn");

completeBtn.addEventListener("click", () => {

    localStorage.setItem("lesson1Complete", "true");

    alert("🎉 Mission Complete!\n\n+500 XP\nMission 2 Unlocked!");

    window.location.href = "index.html";

});