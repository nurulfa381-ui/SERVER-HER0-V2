const completeBtn = document.getElementById("completeBtn");

completeBtn.addEventListener("click",()=>{

localStorage.setItem("lesson3Complete","true");

alert("🎉 Mission Complete!\n\n+800 XP\nMission 4 Unlocked!");

window.location.href="index.html";

});